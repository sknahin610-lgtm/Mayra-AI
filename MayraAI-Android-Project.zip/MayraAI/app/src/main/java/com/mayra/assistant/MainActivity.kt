package com.mayra.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var status: TextView
    private lateinit var tts: TextToSpeech
    private var torchOn = false
    private val voiceRequest = 701
    private val audioPermissionRequest = 702

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 40, 28, 28)
            setBackgroundColor(0xFF101426.toInt())
        }
        val title = TextView(this).apply {
            text = "Mayra AI"
            textSize = 32f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "তোমার ব্যক্তিগত ভয়েস অ্যাসিস্ট্যান্ট"
            textSize = 16f
            setTextColor(0xFFB9C2E8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 24)
        }
        status = TextView(this).apply {
            text = "শুরু করতে মাইক্রোফোন বাটনে চাপ দাও"
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            setPadding(12, 18, 12, 22)
        }
        page.addView(title, matchWrap())
        page.addView(subtitle, matchWrap())
        page.addView(status, matchWrap())
        page.addView(makeButton("🎤  কথা বলো", true) { startVoice() }, buttonParams())
        page.addView(makeButton("📞  কল করার স্ক্রিন", false) { openDialer() }, buttonParams())
        page.addView(makeButton("💬  WhatsApp খোলো", false) { launchPackage("com.whatsapp", "WhatsApp পাওয়া যায়নি") }, buttonParams())
        page.addView(makeButton("🔦  ফ্ল্যাশলাইট চালু / বন্ধ", false) { toggleTorch() }, buttonParams())
        page.addView(makeButton("🔊  ভলিউম বাড়াও", false) { changeVolume(1) }, buttonParams())
        page.addView(makeButton("🔉  ভলিউম কমাও", false) { changeVolume(-1) }, buttonParams())
        val note = TextView(this).apply {
            text = "নিরাপত্তা: কল করার আগে নম্বর নিশ্চিত করো। এই সংস্করণে কল বাটন ডায়ালার খোলে, নিজে থেকে কল করে না।"
            textSize = 12f
            setTextColor(0xFF9CA6C9.toInt())
            gravity = Gravity.CENTER
            setPadding(4, 20, 4, 0)
        }
        page.addView(note, matchWrap())
        val scroll = ScrollView(this)
        scroll.addView(page)
        setContentView(scroll)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun buttonParams() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { setMargins(0, 7, 0, 7) }

    private fun makeButton(label: String, primary: Boolean, action: () -> Unit) =
        Button(this).apply {
            text = label
            textSize = 16f
            isAllCaps = false
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(if (primary) 0xFF6750A4.toInt() else 0xFF29314F.toInt())
            setOnClickListener { action() }
        }

    private fun startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionRequest)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "bn-BD")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Mayra AI-কে বলুন")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            startActivityForResult(intent, voiceRequest)
        } catch (_: Exception) {
            speak("ভয়েস সার্ভিস পাওয়া যাচ্ছে না।")
        }
    }

    @Deprecated("Deprecated by Android; retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == voiceRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val command = words?.firstOrNull().orEmpty()
            status.text = "তুমি বলেছ: $command"
            handleCommand(command.lowercase(Locale.ROOT))
        }
    }

    private fun handleCommand(command: String) {
        when {
            command.contains("ফ্ল্যাশ") || command.contains("torch") || command.contains("flash") ->
                toggleTorch()
            command.contains("হোয়াটসঅ্যাপ") || command.contains("হোয়াটস এপ") || command.contains("whatsapp") ->
                launchPackage("com.whatsapp", "WhatsApp পাওয়া যায়নি")
            command.contains("কল") || command.contains("call") || command.contains("ফোন") ->
                openDialer()
            command.contains("ভলিউম কম") || command.contains("volume down") ->
                changeVolume(-1)
            command.contains("ভলিউম") || command.contains("volume up") ->
                changeVolume(1)
            command.contains("ক্যামেরা") || command.contains("camera") ->
                openCamera()
            command.contains("সেটিংস") || command.contains("settings") ->
                startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            command.contains("ইউটিউব") || command.contains("youtube") ->
                launchPackage("com.google.android.youtube", "YouTube পাওয়া যায়নি")
            command.contains("ক্রোম") || command.contains("chrome") ->
                launchPackage("com.android.chrome", "Chrome পাওয়া যায়নি")
            else -> speak("দুঃখিত, এই কমান্ডটি এখনো শিখিনি।")
        }
    }

    private fun openDialer() {
        startActivity(Intent(Intent.ACTION_DIAL))
        speak("ডায়ালার খুলছি")
    }

    private fun launchPackage(packageName: String, error: String) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) startActivity(launch) else speak(error)
    }

    private fun openCamera() {
        try {
            startActivity(Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE))
        } catch (_: Exception) {
            speak("ক্যামেরা খোলা যাচ্ছে না")
        }
    }

    private fun toggleTorch() {
        try {
            val cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (cameraId == null) {
                speak("এই ফোনে ফ্ল্যাশলাইট পাওয়া যায়নি")
                return
            }
            torchOn = !torchOn
            cameraManager.setTorchMode(cameraId, torchOn)
            speak(if (torchOn) "ফ্ল্যাশলাইট চালু" else "ফ্ল্যাশলাইট বন্ধ")
        } catch (_: Exception) {
            speak("ফ্ল্যাশলাইট নিয়ন্ত্রণ করা যায়নি")
        }
    }

    private fun changeVolume(direction: Int) {
        val audio = getSystemService(AUDIO_SERVICE) as AudioManager
        audio.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            if (direction > 0) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER,
            AudioManager.FLAG_SHOW_UI
        )
        speak(if (direction > 0) "ভলিউম বাড়ানো হয়েছে" else "ভলিউম কমানো হয়েছে")
    }

    private fun speak(message: String) {
        status.text = message
        if (::tts.isInitialized) tts.speak(message, TextToSpeech.QUEUE_FLUSH, null, "mayra_reply")
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("bn", "BD"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.setLanguage(Locale.US)
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionRequest &&
            grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) startVoice() else speak("মাইক্রোফোন অনুমতি ছাড়া ভয়েস কমান্ড চলবে না")
    }

    override fun onDestroy() {
        if (::tts.isInitialized) {
            tts.stop()
            tts.shutdown()
        }
        super.onDestroy()
    }
}
