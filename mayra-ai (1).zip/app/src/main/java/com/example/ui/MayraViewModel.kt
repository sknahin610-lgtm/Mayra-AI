package com.example.ui

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.assistant.AccessibilityCommandOutcome
import com.example.assistant.AccessibilityControlAction
import com.example.assistant.AppLaunchOutcome
import com.example.assistant.DeviceAppLauncher
import com.example.assistant.InstalledAppInfo
import com.example.assistant.MayraAccessibilityService
import com.example.assistant.MayraSpeechRecognizerManager
import com.example.assistant.MayraTtsManager
import com.example.assistant.MayraVoiceService
import com.example.assistant.QuickAppTarget
import com.example.assistant.SpeechRecognitionState
import com.example.assistant.VoiceConversationEvent
import com.example.assistant.VoiceSessionBus
import com.example.data.local.MayraDatabase
import com.example.data.local.MemoryFactEntity
import com.example.data.local.MemoryRepository
import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import java.util.Locale
import java.util.UUID

private const val TAG = "MayraViewModel"

enum class MayraTab {
    ASSISTANT,
    APPS_CONTROL,
    MEMORY_AI
}

enum class AssistantLanguage(val tag: String, val label: String) {
    BENGALI("bn-BD", "বাংলা"),
    ENGLISH("en-US", "EN")
}

sealed interface AiUiState {
    data object Idle : AiUiState
    data object Loading : AiUiState
    data class Streaming(val text: String) : AiUiState
    data class Success(val text: String) : AiUiState
    data class Error(val message: String, val failedPrompt: String? = null) : AiUiState
}

sealed interface AiServerStatus {
    data object Ready : AiServerStatus
    data object Connecting : AiServerStatus
    data class Connected(val latencyMs: Long? = null) : AiServerStatus
    data class Error(val message: String) : AiServerStatus
}

enum class MessageSender {
    USER,
    MAYRA,
    ACTION
}

data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val isStreaming: Boolean = false,
    val actionSucceeded: Boolean = true
)

data class MayraUiState(
    val selectedTab: MayraTab = MayraTab.ASSISTANT,
    val messages: List<ChatMessage> = emptyList(),
    val inputText: String = "",
    val language: AssistantLanguage = AssistantLanguage.BENGALI,
    val autoSpeakEnabled: Boolean = true,
    val statusBanner: String = "হ্যালো! আমি Mayra AI।",
    val speechState: SpeechRecognitionState = SpeechRecognitionState.Idle,
    val aiState: AiUiState = AiUiState.Idle,
    val aiServerStatus: AiServerStatus = AiServerStatus.Ready,
    val isSpeaking: Boolean = false,
    val speakingMessageId: String? = null,
    val isBackgroundVoiceActive: Boolean = false,
    val isServiceListening: Boolean = false,
    val isServiceSpeaking: Boolean = false,
    val allTimeVoiceEnabled: Boolean = true,
    val isAccessibilityEnabled: Boolean = false,
    val memories: List<MemoryFactEntity> = emptyList(),
    val memoryInputText: String = "",
    val installedApps: List<InstalledAppInfo> = emptyList(),
    val appSearchQuery: String = ""
)

private const val PREFS_NAME = "mayra_prefs"
private const val KEY_ALL_TIME_VOICE = "all_time_voice_enabled"

class MayraViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = application.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val ttsManager = MayraTtsManager(application)
    private val speechManager = MayraSpeechRecognizerManager(application)
    private val memoryRepository = MemoryRepository(MayraDatabase.getInstance(application).memoryFactDao())

    private val model by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    """
                    You are Mayra AI (মায়রা), a warm, intelligent, and helpful personal smart assistant.
                    - Respond naturally in Bengali (বাংলা) when the user communicates in Bengali, and in English when addressed in English.
                    - When local memory facts are supplied in context, use them naturally to personalize your reply without sounding robotic.
                    - Keep responses clear, warm, accurate, and conversational (2 to 5 concise sentences for general chat, or structured steps when asked for plans/lists).
                    - Avoid excessive markdown symbols so responses read cleanly aloud via Text-to-Speech.
                    """.trimIndent()
                )
            }
        )
    }

    private var chatSession: Chat? = null
    private var activeGenerationJob: Job? = null
    private var pendingCameraVoiceCommand: String? = null

    private val _cameraPermissionRequests = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val cameraPermissionRequests: SharedFlow<Unit> = _cameraPermissionRequests.asSharedFlow()

    private val _selectedTab = MutableStateFlow(MayraTab.ASSISTANT)
    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    private val _inputText = MutableStateFlow("")
    private val _language = MutableStateFlow(AssistantLanguage.BENGALI)
    private val _autoSpeakEnabled = MutableStateFlow(true)
    private val _statusBanner = MutableStateFlow("হ্যালো! আমি Mayra AI।")
    private val _aiState = MutableStateFlow<AiUiState>(AiUiState.Idle)
    private val _aiServerStatus = MutableStateFlow<AiServerStatus>(AiServerStatus.Ready)
    private val _speakingMessageId = MutableStateFlow<String?>(null)
    private val _allTimeVoiceEnabled = MutableStateFlow(prefs.getBoolean(KEY_ALL_TIME_VOICE, true))
    private val _memoryInputText = MutableStateFlow("")
    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    private val _appSearchQuery = MutableStateFlow("")

    private val coreControlsFlow = combine(
        _selectedTab,
        _messages,
        _inputText,
        _language,
        _autoSpeakEnabled
    ) { tab, msgs, input, lang, autoSpeak ->
        CoreUiSlice(tab, msgs, input, lang, autoSpeak)
    }

    private val statusFlow = combine(
        _statusBanner,
        speechManager.state,
        _aiState,
        _aiServerStatus,
        ttsManager.isSpeaking
    ) { banner, speech, ai, server, speaking ->
        StatusUiSlice(banner, speech, ai, server, speaking)
    }

    private val serviceVoiceFlow = combine(
        MayraVoiceService.isRunning,
        VoiceSessionBus.serviceListening,
        VoiceSessionBus.serviceSpeaking,
        _allTimeVoiceEnabled
    ) { running, listening, speaking, allTimeEnabled ->
        ServiceVoiceSlice(running, listening, speaking, allTimeEnabled)
    }

    private val systemFlow = combine(
        _speakingMessageId,
        serviceVoiceFlow,
        MayraAccessibilityService.isConnected,
        memoryRepository.allMemories,
        _memoryInputText
    ) { speakingId, serviceVoice, accessibilityOn, memories, memInput ->
        SystemUiSlice(speakingId, serviceVoice, accessibilityOn, memories, memInput)
    }

    val uiState: StateFlow<MayraUiState> = combine(
        coreControlsFlow,
        statusFlow,
        systemFlow,
        _installedApps,
        _appSearchQuery
    ) { core, status, sys, apps, query ->
        MayraUiState(
            selectedTab = core.tab,
            messages = core.messages,
            inputText = core.inputText,
            language = core.language,
            autoSpeakEnabled = core.autoSpeakEnabled,
            statusBanner = status.banner,
            speechState = status.speechState,
            aiState = status.aiState,
            aiServerStatus = status.aiServerStatus,
            isSpeaking = status.isSpeaking,
            speakingMessageId = if (status.isSpeaking) sys.speakingMessageId else null,
            isBackgroundVoiceActive = sys.serviceVoice.isRunning,
            isServiceListening = sys.serviceVoice.isListening,
            isServiceSpeaking = sys.serviceVoice.isSpeaking,
            allTimeVoiceEnabled = sys.serviceVoice.allTimeEnabled,
            isAccessibilityEnabled = sys.isAccessibilityEnabled,
            memories = sys.memories,
            memoryInputText = sys.memoryInputText,
            installedApps = apps,
            appSearchQuery = query
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = MayraUiState(allTimeVoiceEnabled = prefs.getBoolean(KEY_ALL_TIME_VOICE, true))
    )

    init {
        ttsManager.setOnInitialReady {
            if (_autoSpeakEnabled.value && _messages.value.isEmpty() && !MayraVoiceService.isRunning.value) {
                ttsManager.speak("হ্যালো! আমি মায়রা। তোমাকে কীভাবে সাহায্য করতে পারি?")
            }
        }
        refreshInstalledApps()
        observeVoiceServiceEvents()
    }

    private fun observeVoiceServiceEvents() {
        viewModelScope.launch {
            VoiceSessionBus.events.collect { event ->
                when (event) {
                    is VoiceConversationEvent.UserSpoken -> {
                        _messages.value = _messages.value + ChatMessage(
                            sender = MessageSender.USER,
                            text = event.text
                        )
                        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
                            "তুমি বলেছ: ${event.text}"
                        } else {
                            "You said: ${event.text}"
                        }
                    }
                    is VoiceConversationEvent.AiReplyChunk -> {
                        val existing = _messages.value.any { it.id == event.messageId }
                        if (!existing) {
                            _messages.value = _messages.value + ChatMessage(
                                id = event.messageId,
                                sender = MessageSender.MAYRA,
                                text = event.text,
                                isStreaming = event.isStreaming
                            )
                        } else {
                            updateMessage(event.messageId) {
                                it.copy(text = event.text, isStreaming = event.isStreaming)
                            }
                        }
                        if (!event.isStreaming && event.text.isNotBlank()) {
                            _aiServerStatus.value = AiServerStatus.Connected()
                        }
                    }
                    is VoiceConversationEvent.ActionPerformed -> {
                        _messages.value = _messages.value + ChatMessage(
                            sender = MessageSender.ACTION,
                            text = event.text,
                            actionSucceeded = event.succeeded
                        )
                        _statusBanner.value = event.text
                    }
                    is VoiceConversationEvent.ErrorOccurred -> {
                        _aiState.value = AiUiState.Error(event.message)
                        _aiServerStatus.value = AiServerStatus.Error(event.message)
                        _statusBanner.value = event.message
                    }
                }
            }
        }
    }

    fun selectTab(tab: MayraTab) {
        _selectedTab.value = tab
        if (tab == MayraTab.APPS_CONTROL && _installedApps.value.isEmpty()) {
            refreshInstalledApps()
        }
    }

    fun refreshInstalledApps() {
        viewModelScope.launch {
            val apps = withContext(Dispatchers.IO) {
                DeviceAppLauncher.queryInstalledApps(getApplication())
            }
            _installedApps.value = apps
        }
    }

    fun onAppSearchQueryChanged(query: String) {
        _appSearchQuery.value = query
    }

    fun onInputTextChanged(text: String) {
        _inputText.value = text
    }

    fun onMemoryInputChanged(text: String) {
        _memoryInputText.value = text
    }

    fun addMemoryFromInput() {
        val text = _memoryInputText.value.trim()
        if (text.isEmpty()) return
        _memoryInputText.value = ""
        viewModelScope.launch {
            memoryRepository.saveMemory(text, MemoryFactEntity.CATEGORY_NOTE)
        }
    }

    fun deleteMemory(id: Int) {
        viewModelScope.launch {
            memoryRepository.deleteMemory(id)
        }
    }

    fun clearAllMemories() {
        viewModelScope.launch {
            memoryRepository.clearAll()
        }
    }

    fun toggleLanguage() {
        val next = if (_language.value == AssistantLanguage.BENGALI) {
            AssistantLanguage.ENGLISH
        } else {
            AssistantLanguage.BENGALI
        }
        _language.value = next
        VoiceSessionBus.setLanguageTag(next.tag)
        _statusBanner.value = if (next == AssistantLanguage.BENGALI) {
            "হ্যালো! আমি Mayra AI।"
        } else {
            "Hello! I am Mayra AI."
        }
    }

    fun toggleAutoSpeak() {
        val next = !_autoSpeakEnabled.value
        _autoSpeakEnabled.value = next
        if (!next) {
            ttsManager.stop()
            _speakingMessageId.value = null
        }
    }

    fun startBackgroundVoiceService() {
        speechManager.stopListening()
        ttsManager.stop()
        _speakingMessageId.value = null
        _allTimeVoiceEnabled.value = true
        prefs.edit().putBoolean(KEY_ALL_TIME_VOICE, true).apply()
        VoiceSessionBus.setLanguageTag(_language.value.tag)
        if (!MayraVoiceService.isRunning.value) {
            MayraVoiceService.start(getApplication())
        }
        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
            "Mayra AI Voice চালু হয়েছে"
        } else {
            "Mayra AI Voice is active"
        }
    }

    fun stopBackgroundVoiceService() {
        _allTimeVoiceEnabled.value = false
        prefs.edit().putBoolean(KEY_ALL_TIME_VOICE, false).apply()
        MayraVoiceService.stop(getApplication())
        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
            "Mayra Voice বন্ধ আছে"
        } else {
            "Mayra Voice is stopped"
        }
    }

    fun startVoiceListening() {
        ttsManager.stop()
        _speakingMessageId.value = null

        speechManager.startListening(
            languageTag = _language.value.tag,
            onResult = { transcript ->
                _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
                    "তুমি বলেছ: $transcript"
                } else {
                    "You said: $transcript"
                }
                submitPrompt(transcript)
            },
            onUnavailable = {
                val msg = if (_language.value == AssistantLanguage.BENGALI) {
                    "তোমার ফোনে Speech Recognition পাওয়া যাচ্ছে না"
                } else {
                    "Speech recognition is unavailable on this device."
                }
                _statusBanner.value = msg
                if (_autoSpeakEnabled.value) {
                    ttsManager.speak(msg)
                }
            }
        )
    }

    fun stopVoiceListening() {
        speechManager.stopListening()
        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
            "হ্যালো! আমি Mayra AI।"
        } else {
            "Hello! I am Mayra AI."
        }
    }

    fun onMicPermissionDenied() {
        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
            "ভয়েস ব্যবহারের জন্য মাইক্রোফোন অনুমতি প্রয়োজন।"
        } else {
            "Microphone permission is required for voice commands."
        }
    }

    fun launchQuickApp(target: QuickAppTarget, fromVoiceCommand: String? = null) {
        if (target == QuickAppTarget.CAMERA) {
            val hasCameraPermission = ContextCompat.checkSelfPermission(
                getApplication(),
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasCameraPermission) {
                pendingCameraVoiceCommand = fromVoiceCommand
                _cameraPermissionRequests.tryEmit(Unit)
                return
            }
        }

        executeAppOutcome(DeviceAppLauncher.launch(getApplication(), target), fromVoiceCommand)
    }

    fun launchInstalledApp(app: InstalledAppInfo, fromVoiceCommand: String? = null) {
        val outcome = DeviceAppLauncher.launchPackage(getApplication(), app.packageName, app.label)
        executeAppOutcome(outcome, fromVoiceCommand)
    }

    private fun launchUtilityIntent(name: String, intent: Intent, fromVoiceCommand: String?) {
        val outcome = DeviceAppLauncher.launchIntent(getApplication(), name, intent)
        executeAppOutcome(outcome, fromVoiceCommand)
    }

    private fun executeAppOutcome(outcome: AppLaunchOutcome, fromVoiceCommand: String?) {
        if (fromVoiceCommand != null) {
            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.USER,
                text = fromVoiceCommand
            )
        }

        val useBengali = _language.value == AssistantLanguage.BENGALI ||
            (fromVoiceCommand?.any { it in '\u0980'..'\u09FF' } == true)

        val (feedbackText, succeeded) = when (outcome) {
            is AppLaunchOutcome.Launched ->
                (if (useBengali) outcome.feedbackBn else outcome.feedbackEn) to true
            is AppLaunchOutcome.NotAvailable ->
                (if (useBengali) outcome.feedbackBn else outcome.feedbackEn) to false
        }

        val actionMsg = ChatMessage(
            sender = MessageSender.ACTION,
            text = feedbackText,
            actionSucceeded = succeeded
        )
        _messages.value = _messages.value + actionMsg
        _statusBanner.value = feedbackText

        if (_autoSpeakEnabled.value) {
            _speakingMessageId.value = actionMsg.id
            ttsManager.speak(feedbackText)
        }
    }

    fun onCameraPermissionResult(granted: Boolean) {
        val pendingVoice = pendingCameraVoiceCommand
        pendingCameraVoiceCommand = null
        if (granted) {
            executeAppOutcome(DeviceAppLauncher.launch(getApplication(), QuickAppTarget.CAMERA), pendingVoice)
        } else {
            if (pendingVoice != null) {
                _messages.value = _messages.value + ChatMessage(
                    sender = MessageSender.USER,
                    text = pendingVoice
                )
            }
            val msg = if (_language.value == AssistantLanguage.BENGALI) {
                "ক্যামেরা খোলার জন্য ক্যামেরা অনুমতি প্রয়োজন।"
            } else {
                "Camera permission is required to open the camera."
            }
            _statusBanner.value = msg
            if (_autoSpeakEnabled.value) {
                ttsManager.speak(msg)
            }
        }
    }

    fun openAccessibilitySettings() {
        MayraAccessibilityService.openAccessibilitySettings(getApplication())
    }

    fun triggerAccessibilityAction(
        action: AccessibilityControlAction,
        fromVoiceCommand: String? = null
    ) {
        if (fromVoiceCommand != null) {
            _messages.value = _messages.value + ChatMessage(
                sender = MessageSender.USER,
                text = fromVoiceCommand
            )
        }

        val useBengali = _language.value == AssistantLanguage.BENGALI ||
            (fromVoiceCommand?.any { it in '\u0980'..'\u09FF' } == true)

        val (feedbackText, succeeded) = when (val outcome = MayraAccessibilityService.performAction(action)) {
            is AccessibilityCommandOutcome.Executed ->
                (if (useBengali) outcome.action.feedbackBn else outcome.action.feedbackEn) to true
            is AccessibilityCommandOutcome.ServiceDisabled ->
                (if (useBengali) {
                    "Accessibility কন্ট্রোল চালু নেই। Apps & Control ট্যাব থেকে চালু করো।"
                } else {
                    "Accessibility Control is disabled. Enable it in Apps & Control."
                }) to false
            is AccessibilityCommandOutcome.UnsupportedApi ->
                (if (useBengali) {
                    "এই অ্যান্ড্রয়েড ভার্সনে অ্যাকশনটি সমর্থিত নয়।"
                } else {
                    "This action is not supported on this Android version."
                }) to false
        }

        val actionMsg = ChatMessage(
            sender = MessageSender.ACTION,
            text = feedbackText,
            actionSucceeded = succeeded
        )
        _messages.value = _messages.value + actionMsg
        _statusBanner.value = feedbackText

        if (_autoSpeakEnabled.value) {
            _speakingMessageId.value = actionMsg.id
            ttsManager.speak(feedbackText)
        }
    }

    fun submitCurrentInput() {
        val text = _inputText.value.trim()
        if (text.isEmpty()) return
        _inputText.value = ""
        submitPrompt(text)
    }

    fun submitPrompt(rawPrompt: String) {
        val prompt = rawPrompt.trim()
        if (prompt.isEmpty()) return

        // 1. Local Memory save intent
        val memoryMatch = MemoryRepository.detectMemoryCommand(prompt)
        if (memoryMatch != null) {
            viewModelScope.launch {
                memoryRepository.saveMemory(memoryMatch.content, memoryMatch.category)
            }
            val useBengali = _language.value == AssistantLanguage.BENGALI ||
                prompt.any { it in '\u0980'..'\u09FF' }
            val reply = if (useBengali) {
                "লোকাল মেমোরিতে সংরক্ষণ করেছি: ${memoryMatch.content}"
            } else {
                "Saved to local memory: ${memoryMatch.content}"
            }
            _messages.value = _messages.value +
                ChatMessage(sender = MessageSender.USER, text = prompt) +
                ChatMessage(sender = MessageSender.ACTION, text = reply, actionSucceeded = true)
            _statusBanner.value = reply
            if (_autoSpeakEnabled.value) {
                ttsManager.speak(reply)
            }
            return
        }

        // 2. Accessibility Control voice/text action
        val accessibilityAction = MayraAccessibilityService.detectActionCommand(prompt)
        if (accessibilityAction != null) {
            triggerAccessibilityAction(accessibilityAction, fromVoiceCommand = prompt)
            return
        }

        // 3. Phone App Launcher (Quick apps, system intents, or installed apps)
        val detectedApp = DeviceAppLauncher.detectAppCommand(prompt)
        if (detectedApp != null) {
            launchQuickApp(detectedApp, fromVoiceCommand = prompt)
            return
        }

        val utilityIntent = DeviceAppLauncher.detectSystemUtilityIntent(prompt)
        if (utilityIntent != null) {
            launchUtilityIntent(utilityIntent.first, utilityIntent.second, fromVoiceCommand = prompt)
            return
        }

        val matchingInstalledApp = findMatchingInstalledApp(prompt)
        if (matchingInstalledApp != null) {
            launchInstalledApp(matchingInstalledApp, fromVoiceCommand = prompt)
            return
        }

        // 4. Gemini AI Server Connection (with Local Memory context)
        sendToGemini(prompt)
    }

    private fun findMatchingInstalledApp(rawPrompt: String): InstalledAppInfo? {
        val lower = rawPrompt.lowercase(Locale.ROOT).trim()
        val hasOpenVerb = lower.contains("open") || lower.contains("launch") ||
            lower.contains("খোল") || lower.contains("চালু") || lower.contains("ওপেন")
        if (!hasOpenVerb) return null

        return _installedApps.value.firstOrNull { app ->
            val appLower = app.label.lowercase(Locale.ROOT)
            appLower.length >= 3 && lower.contains(appLower)
        }
    }

    private fun sendToGemini(prompt: String) {
        activeGenerationJob?.cancel()
        ttsManager.stop()
        _speakingMessageId.value = null

        val userMessage = ChatMessage(
            sender = MessageSender.USER,
            text = prompt
        )
        val assistantMsgId = UUID.randomUUID().toString()
        val streamingPlaceholder = ChatMessage(
            id = assistantMsgId,
            sender = MessageSender.MAYRA,
            text = "",
            isStreaming = true
        )

        _messages.value = _messages.value + userMessage + streamingPlaceholder
        _aiState.value = AiUiState.Loading
        _aiServerStatus.value = AiServerStatus.Connecting
        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
            "মায়রা ভাবছে..."
        } else {
            "Mayra is thinking..."
        }

        activeGenerationJob = viewModelScope.launch {
            val accumulated = StringBuilder()
            val startedAt = System.currentTimeMillis()
            try {
                val memories = memoryRepository.getRecentMemoriesSnapshot(15)
                val promptWithMemory = if (memories.isNotEmpty()) {
                    val factsBlock = memories.joinToString("\n") { "- ${it.content}" }
                    "[Local Memory Context:\n$factsBlock\n]\nUser message: $prompt"
                } else {
                    prompt
                }

                val chat = chatSession ?: model.startChat().also { chatSession = it }
                withTimeout(60_000L) {
                    chat.sendMessageStream(promptWithMemory).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        if (chunkText.isNotEmpty()) {
                            accumulated.append(chunkText)
                            val currentText = accumulated.toString()
                            _aiState.value = AiUiState.Streaming(currentText)
                            updateMessage(assistantMsgId) {
                                it.copy(text = currentText, isStreaming = true)
                            }
                        }
                    }
                }

                val finalText = accumulated.toString().trim()
                if (finalText.isNotEmpty()) {
                    val latency = System.currentTimeMillis() - startedAt
                    _aiServerStatus.value = AiServerStatus.Connected(latencyMs = latency)
                    updateMessage(assistantMsgId) {
                        it.copy(text = finalText, isStreaming = false)
                    }
                    _aiState.value = AiUiState.Success(finalText)
                    _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
                        "হ্যালো! আমি Mayra AI।"
                    } else {
                        "Hello! I am Mayra AI."
                    }
                    if (_autoSpeakEnabled.value) {
                        _speakingMessageId.value = assistantMsgId
                        ttsManager.speak(finalText)
                    }
                } else {
                    removeMessage(assistantMsgId)
                    val emptyMsg = if (_language.value == AssistantLanguage.BENGALI) {
                        "মায়রা কোনো উত্তর তৈরি করতে পারেনি। অনুগ্রহ করে আবার চেষ্টা করো।"
                    } else {
                        "Mayra returned an empty response. Please try again."
                    }
                    _aiState.value = AiUiState.Error(emptyMsg, failedPrompt = prompt)
                    _aiServerStatus.value = AiServerStatus.Error(emptyMsg)
                    _statusBanner.value = emptyMsg
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "Gemini streaming timed out", e)
                finalizeOrRemovePartial(assistantMsgId, accumulated.toString())
                val timeoutMsg = if (_language.value == AssistantLanguage.BENGALI) {
                    "অনুরোধের সময় শেষ হয়েছে (৬০ সেকেন্ড)। আবার চেষ্টা করো।"
                } else {
                    "Request timed out after 60 seconds. Please try again."
                }
                _aiState.value = AiUiState.Error(timeoutMsg, failedPrompt = prompt)
                _aiServerStatus.value = AiServerStatus.Error(timeoutMsg)
                _statusBanner.value = timeoutMsg
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "Firebase AI generation failed", e)
                finalizeOrRemovePartial(assistantMsgId, accumulated.toString())
                val errorMsg = e.localizedMessage?.takeIf { it.isNotBlank() }
                    ?: if (_language.value == AssistantLanguage.BENGALI) {
                        "উত্তর তৈরি করতে সমস্যা হয়েছে। নেটওয়ার্ক পরীক্ষা করো।"
                    } else {
                        "Failed to generate response. Please check your connection."
                    }
                _aiState.value = AiUiState.Error(errorMsg, failedPrompt = prompt)
                _aiServerStatus.value = AiServerStatus.Error(errorMsg)
                _statusBanner.value = errorMsg
            }
        }
    }

    fun testAiServerConnection() {
        viewModelScope.launch {
            _aiServerStatus.value = AiServerStatus.Connecting
            val startedAt = System.currentTimeMillis()
            try {
                val response = withTimeout(30_000L) {
                    model.generateContent("Reply with a single word: OK")
                }
                val text = response.text
                if (!text.isNullOrBlank()) {
                    _aiServerStatus.value = AiServerStatus.Connected(
                        latencyMs = System.currentTimeMillis() - startedAt
                    )
                } else {
                    _aiServerStatus.value = AiServerStatus.Error("AI server returned an empty response.")
                }
            } catch (e: TimeoutCancellationException) {
                Log.e(TAG, "AI server health check timed out", e)
                _aiServerStatus.value = AiServerStatus.Error("AI server timed out after 30s.")
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e(TAG, "AI server connection test failed", e)
                _aiServerStatus.value = AiServerStatus.Error(
                    e.localizedMessage ?: "Unable to reach Firebase AI server."
                )
            }
        }
    }

    fun retryLastFailed() {
        val currentError = _aiState.value as? AiUiState.Error ?: return
        val prompt = currentError.failedPrompt ?: return
        _aiState.value = AiUiState.Idle
        submitPrompt(prompt)
    }

    fun dismissError() {
        if (_aiState.value is AiUiState.Error) {
            _aiState.value = AiUiState.Idle
        }
    }

    fun toggleSpeakMessage(message: ChatMessage) {
        if (_speakingMessageId.value == message.id && ttsManager.isSpeaking.value) {
            ttsManager.stop()
            _speakingMessageId.value = null
        } else {
            _speakingMessageId.value = message.id
            ttsManager.speak(message.text)
        }
    }

    fun clearConversation() {
        activeGenerationJob?.cancel()
        ttsManager.stop()
        _speakingMessageId.value = null
        chatSession = null
        _messages.value = emptyList()
        _aiState.value = AiUiState.Idle
        _statusBanner.value = if (_language.value == AssistantLanguage.BENGALI) {
            "হ্যালো! আমি Mayra AI।"
        } else {
            "Hello! I am Mayra AI."
        }
    }

    private fun updateMessage(id: String, transform: (ChatMessage) -> ChatMessage) {
        _messages.value = _messages.value.map { msg ->
            if (msg.id == id) transform(msg) else msg
        }
    }

    private fun removeMessage(id: String) {
        _messages.value = _messages.value.filterNot { it.id == id }
    }

    private fun finalizeOrRemovePartial(id: String, partial: String) {
        if (partial.isBlank()) {
            removeMessage(id)
        } else {
            updateMessage(id) { it.copy(text = partial, isStreaming = false) }
        }
    }

    override fun onCleared() {
        activeGenerationJob?.cancel()
        speechManager.destroy()
        ttsManager.shutdown()
        super.onCleared()
    }

    private data class CoreUiSlice(
        val tab: MayraTab,
        val messages: List<ChatMessage>,
        val inputText: String,
        val language: AssistantLanguage,
        val autoSpeakEnabled: Boolean
    )

    private data class StatusUiSlice(
        val banner: String,
        val speechState: SpeechRecognitionState,
        val aiState: AiUiState,
        val aiServerStatus: AiServerStatus,
        val isSpeaking: Boolean
    )

    private data class ServiceVoiceSlice(
        val isRunning: Boolean,
        val isListening: Boolean,
        val isSpeaking: Boolean,
        val allTimeEnabled: Boolean
    )

    private data class SystemUiSlice(
        val speakingMessageId: String?,
        val serviceVoice: ServiceVoiceSlice,
        val isAccessibilityEnabled: Boolean,
        val memories: List<MemoryFactEntity>,
        val memoryInputText: String
    )
}
