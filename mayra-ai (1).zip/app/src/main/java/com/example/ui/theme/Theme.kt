package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val MayraDarkColorScheme = darkColorScheme(
    primary = IceBluePrimary,
    onPrimary = IceBlueOnPrimary,
    primaryContainer = IceBlueContainer,
    onPrimaryContainer = IceBlueOnContainer,
    secondary = AuroraCyanSecondary,
    onSecondary = AuroraCyanOnSecondary,
    secondaryContainer = AuroraCyanContainer,
    onSecondaryContainer = AuroraCyanOnContainer,
    tertiary = StarlightVioletTertiary,
    onTertiary = StarlightOnTertiary,
    tertiaryContainer = StarlightContainer,
    onTertiaryContainer = StarlightOnContainer,
    background = MidnightVoid,
    onBackground = StarlightWhite,
    surface = MidnightSurface,
    onSurface = StarlightWhite,
    surfaceVariant = MidnightSurfaceVariant,
    onSurfaceVariant = MistGray,
    surfaceContainerHigh = MidnightElevated,
    outline = CosmicOutline,
    outlineVariant = CosmicOutlineVariant,
    error = RoseError,
    onError = RoseOnError,
    errorContainer = RoseErrorContainer,
    onErrorContainer = RoseOnErrorContainer
)

private val MayraLightColorScheme = lightColorScheme(
    primary = DaylightPrimary,
    onPrimary = DaylightOnPrimary,
    primaryContainer = IceBlueOnContainer,
    onPrimaryContainer = IceBlueOnPrimary,
    secondary = AuroraCyanContainer,
    onSecondary = StarlightWhite,
    background = DaylightBackground,
    onBackground = DaylightTextPrimary,
    surface = DaylightSurface,
    onSurface = DaylightTextPrimary,
    surfaceVariant = DaylightSurfaceVariant,
    onSurfaceVariant = DaylightTextSecondary
)

val MayraShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun MayraTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) MayraDarkColorScheme else MayraLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = MayraTypography,
        shapes = MayraShapes,
        content = content
    )
}
