package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ChatBubble
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.assistant.QuickAppTarget
import com.example.ui.AssistantLanguage
import com.example.ui.theme.CameraAccent
import com.example.ui.theme.ChromeAccent
import com.example.ui.theme.WhatsAppAccent
import com.example.ui.theme.YouTubeAccent

private data class QuickAppUiItem(
    val target: QuickAppTarget,
    val labelResId: Int,
    val icon: ImageVector,
    val accent: Color,
    val testTag: String
)

private val quickAppItems = listOf(
    QuickAppUiItem(
        target = QuickAppTarget.YOUTUBE,
        labelResId = R.string.app_youtube,
        icon = Icons.Rounded.PlayArrow,
        accent = YouTubeAccent,
        testTag = "quick_app_youtube"
    ),
    QuickAppUiItem(
        target = QuickAppTarget.WHATSAPP,
        labelResId = R.string.app_whatsapp,
        icon = Icons.Rounded.ChatBubble,
        accent = WhatsAppAccent,
        testTag = "quick_app_whatsapp"
    ),
    QuickAppUiItem(
        target = QuickAppTarget.CAMERA,
        labelResId = R.string.app_camera,
        icon = Icons.Rounded.PhotoCamera,
        accent = CameraAccent,
        testTag = "quick_app_camera"
    ),
    QuickAppUiItem(
        target = QuickAppTarget.CHROME,
        labelResId = R.string.app_chrome,
        icon = Icons.Rounded.Public,
        accent = ChromeAccent,
        testTag = "quick_app_chrome"
    )
)

@Composable
fun QuickAppsDock(
    language: AssistantLanguage,
    onLaunchApp: (QuickAppTarget) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = stringResource(
                id = if (language == AssistantLanguage.BENGALI) {
                    R.string.quick_actions_title_bn
                } else {
                    R.string.quick_actions_title_en
                }
            ),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(horizontal = 4.dp)
        )

        Spacer(modifier = Modifier.height(8.dp))

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            contentPadding = PaddingValues(horizontal = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            items(quickAppItems, key = { it.target.name }) { item ->
                val label = stringResource(id = item.labelResId)
                Surface(
                    onClick = { onLaunchApp(item.target) },
                    shape = MaterialTheme.shapes.medium,
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f),
                    border = BorderStroke(
                        width = 1.dp,
                        color = item.accent.copy(alpha = 0.35f)
                    ),
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag(item.testTag)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 11.dp)
                    ) {
                        Surface(
                            shape = MaterialTheme.shapes.small,
                            color = item.accent.copy(alpha = 0.16f),
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = item.icon,
                                contentDescription = label,
                                tint = item.accent,
                                modifier = Modifier
                                    .padding(5.dp)
                                    .size(18.dp)
                            )
                        }
                        Text(
                            text = label,
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
