package com.example.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.MayraDatabase
import com.example.data.local.MemoryRepository
import com.google.firebase.Firebase
import com.google.firebase.ai.Chat
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.content
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeout
import java.util.Locale
import java.util.UUID

private const val TAG = "MayraVoiceService"
private const val CHANNEL_ID = "mayra_voice"
private const val NOTIFICATION_ID = 101

class MayraVoiceService : Service() {

    private var recognizer: SpeechRecognizer? = null
    private var speaker: TextToSpeech? = null
    private var femaleBengaliVoice: Voice? = null
    private var femaleEnglishVoice: Voice? = null

    @Volatile
    private var isTtsReady = false

    @Volatile
    private var isTtsSpeaking = false

    @Volatile
    private var isAiGenerating = false

    @Volatile
    private var isServiceDestroyed = false

    private val handler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var memoryRepository: MemoryRepository
    private var activeAiJob: Job? = null
    private var chatSession: Chat? = null

    private val aiModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            systemInstruction = content {
                text(
                    """
                    You are Mayra AI (মায়রা), a warm, friendly always-on Bengali and English voice assistant.
                    - Respond naturally in Bengali (বাংলা) when spoken to in Bengali, and in English when spoken to in English.
                    - When local memory facts are supplied, use them naturally to personalize your reply.
                    - Keep spoken responses concise, clear, and conversational (1 to 4 sentences) with zero markdown formatting so Text-to-Speech sounds natural.
                    """.trimIndent()
                )
            }
        )
    }

    override fun onCreate() {
        super.onCreate()
        _isRunning.value = true
        memoryRepository = MemoryRepository(MayraDatabase.getInstance(this).memoryFactDao())

        val notification = buildForegroundNotification()
        val serviceType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        } else {
            0
        }
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, serviceType)
        } catch (e: SecurityException) {
            Log.e(TAG, "Cannot start microphone foreground service without permission", e)
            stopSelf()
            return
        }

        speaker = TextToSpeech(this) { result ->
            if (result == TextToSpeech.SUCCESS && !isServiceDestroyed) {
                isTtsReady = true
                configureTtsVoices()
                val greeting = if (VoiceSessionBus.preferredLanguageTag.value.startsWith("bn")) {
                    getString(R.string.service_greeting_bn)
                } else {
                    getString(R.string.service_greeting_en)
                }
                speak(greeting)
            } else if (!isServiceDestroyed) {
                scheduleRestart(300L)
            }
        }

        speaker?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                isTtsSpeaking = true
                VoiceSessionBus.setServiceSpeaking(true)
                handler.post { stopRecognitionQuietly() }
            }

            override fun onDone(utteranceId: String?) {
                onTtsFinished()
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
                onTtsFinished()
            }

            override fun onError(utteranceId: String?, errorCode: Int) {
                onTtsFinished()
            }
        })

        // Start listening shortly in case TTS takes a moment or isn't greeting immediately
        scheduleRestart(1200L)
    }

    private fun onTtsFinished() {
        isTtsSpeaking = false
        VoiceSessionBus.setServiceSpeaking(false)
        if (!isServiceDestroyed && !isAiGenerating) {
            handler.post { scheduleRestart(300L) }
        }
    }

    private fun buildForegroundNotification(): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            val channel = NotificationChannel(
                CHANNEL_ID,
                getString(R.string.service_channel_name),
                NotificationManager.IMPORTANCE_LOW
            )
            nm?.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, MayraVoiceService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.service_notif_title))
            .setContentText(getString(R.string.service_notif_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(openPendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                getString(R.string.service_stop_action),
                stopPendingIntent
            )
            .build()
    }

    private fun configureTtsVoices() {
        val engine = speaker ?: return
        engine.language = Locale.forLanguageTag("bn-BD")
        val voices = runCatching { engine.voices }.getOrNull().orEmpty()
        femaleBengaliVoice = findPreferredFemaleVoice(voices, "bn")
        femaleEnglishVoice = findPreferredFemaleVoice(voices, "en")
        femaleBengaliVoice?.let { engine.voice = it }
    }

    private fun findPreferredFemaleVoice(voices: Set<Voice>, langCode: String): Voice? {
        val matches = voices.filter { it.locale.language.equals(langCode, ignoreCase = true) }
        return matches.firstOrNull { voice ->
            val features = voice.features?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val name = voice.name.lowercase(Locale.ROOT)
            features.contains("female") || name.contains("female") || name.contains("bn-bd-x-ban")
        } ?: matches.firstOrNull()
    }

    private fun stopRecognitionQuietly() {
        VoiceSessionBus.setServiceListening(false)
        runCatching {
            recognizer?.cancel()
            recognizer?.destroy()
        }
        recognizer = null
    }

    private fun startRecognition() {
        if (isServiceDestroyed || isTtsSpeaking || isAiGenerating) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "Speech recognition unavailable on this device")
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            Log.w(TAG, "RECORD_AUDIO permission missing; stopping voice service")
            stopSelf()
            return
        }

        stopRecognitionQuietly()

        val speech = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = speech

        speech.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                VoiceSessionBus.setServiceListening(true)
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                VoiceSessionBus.setServiceListening(false)
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}

            override fun onResults(results: Bundle?) {
                VoiceSessionBus.setServiceListening(false)
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val spoken = words?.firstOrNull()?.trim().orEmpty()
                if (spoken.isNotEmpty()) {
                    handleSpokenInput(spoken)
                } else {
                    scheduleRestart(500L)
                }
            }

            override fun onError(error: Int) {
                VoiceSessionBus.setServiceListening(false)
                if (!isServiceDestroyed && !isTtsSpeaking && !isAiGenerating) {
                    val retryDelay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1000L else 600L
                    scheduleRestart(retryDelay)
                }
            }
        })

        val langTag = VoiceSessionBus.preferredLanguageTag.value
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        }

        runCatching { speech.startListening(intent) }
            .onFailure {
                VoiceSessionBus.setServiceListening(false)
                Log.e(TAG, "Failed to start SpeechRecognizer in service", it)
                scheduleRestart(1000L)
            }
    }

    private fun scheduleRestart(delayMs: Long = 600L) {
        if (isServiceDestroyed || isTtsSpeaking || isAiGenerating) return
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ startRecognition() }, delayMs)
    }

    private fun handleSpokenInput(rawSpoken: String) {
        val command = rawSpoken.lowercase(Locale.ROOT).trim()
        VoiceSessionBus.emit(VoiceConversationEvent.UserSpoken(rawSpoken))

        val memoryMatch = MemoryRepository.detectMemoryCommand(rawSpoken)
        if (memoryMatch != null) {
            serviceScope.launch {
                memoryRepository.saveMemory(memoryMatch.content, memoryMatch.category)
            }
            val reply = "মনে রেখেছি: ${memoryMatch.content}"
            VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(reply, succeeded = true))
            speak(reply)
            return
        }

        val accessibilityAction = MayraAccessibilityService.detectActionCommand(command)
        if (accessibilityAction != null) {
            when (val outcome = MayraAccessibilityService.performAction(accessibilityAction)) {
                is AccessibilityCommandOutcome.Executed -> {
                    VoiceSessionBus.emit(
                        VoiceConversationEvent.ActionPerformed(outcome.action.feedbackBn, true)
                    )
                    speak(outcome.action.feedbackBn)
                }
                is AccessibilityCommandOutcome.ServiceDisabled -> {
                    val msg = "Accessibility কন্ট্রোল চালু নেই।"
                    VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(msg, false))
                    speak(msg)
                }
                is AccessibilityCommandOutcome.UnsupportedApi -> {
                    val msg = "এই ডিভাইসে অ্যাকশনটি সমর্থিত নয়।"
                    VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(msg, false))
                    speak(msg)
                }
            }
            return
        }

        val utilityIntent = DeviceAppLauncher.detectSystemUtilityIntent(command)
        if (utilityIntent != null) {
            val outcome = DeviceAppLauncher.launchIntent(this, utilityIntent.first, utilityIntent.second)
            val (msg, ok) = when (outcome) {
                is AppLaunchOutcome.Launched -> outcome.feedbackBn to true
                is AppLaunchOutcome.NotAvailable -> outcome.feedbackBn to false
            }
            VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(msg, ok))
            speak(msg)
            return
        }

        when {
            command == "হ্যালো মায়রা" ||
                command == "হ্যালো মায়রা" ||
                command == "hey mayra" -> {
                val reply = getString(R.string.service_wake_reply_bn)
                VoiceSessionBus.emit(
                    VoiceConversationEvent.AiReplyChunk(
                        messageId = UUID.randomUUID().toString(),
                        text = reply,
                        isStreaming = false
                    )
                )
                speak(reply)
            }
            command.contains("বন্ধ হও") || command.contains("stop mayra") -> {
                val msg = getString(R.string.service_stopping_bn)
                VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(msg, true))
                speak(msg)
                handler.postDelayed({ stopSelf() }, 1200L)
            }
            command.contains("ইউটিউব") || command.contains("youtube") -> {
                launchTargetApp(QuickAppTarget.YOUTUBE)
            }
            command.contains("হোয়াটসঅ্যাপ") ||
                command.contains("হোয়াটসঅ্যাপ") ||
                command.contains("whatsapp") -> {
                launchTargetApp(QuickAppTarget.WHATSAPP)
            }
            command.contains("ক্রোম") || command.contains("chrome") -> {
                launchTargetApp(QuickAppTarget.CHROME)
            }
            command.contains("ক্যামেরা") || command.contains("camera") -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                    == PackageManager.PERMISSION_GRANTED
                ) {
                    launchTargetApp(QuickAppTarget.CAMERA)
                } else {
                    val msg = getString(R.string.camera_permission_needed_bn)
                    VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(msg, false))
                    speak(msg)
                }
            }
            else -> {
                askGeminiAndSpeak(rawSpoken)
            }
        }
    }

    private fun askGeminiAndSpeak(userPrompt: String) {
        activeAiJob?.cancel()
        isAiGenerating = true
        stopRecognitionQuietly()

        val messageId = UUID.randomUUID().toString()
        VoiceSessionBus.emit(VoiceConversationEvent.AiReplyChunk(messageId, "", isStreaming = true))

        activeAiJob = serviceScope.launch {
            val accumulated = StringBuilder()
            try {
                val memories = memoryRepository.getRecentMemoriesSnapshot(15)
                val promptWithMemory = if (memories.isNotEmpty()) {
                    val factsBlock = memories.joinToString("\n") { "- ${it.content}" }
                    "[Local Memory Context:\n$factsBlock\n]\nUser spoken message: $userPrompt"
                } else {
                    userPrompt
                }

                val chat = chatSession ?: aiModel.startChat().also { chatSession = it }
                withTimeout(45_000L) {
                    chat.sendMessageStream(promptWithMemory).collect { chunk ->
                        val chunkText = chunk.text.orEmpty()
                        if (chunkText.isNotEmpty()) {
                            accumulated.append(chunkText)
                            VoiceSessionBus.emit(
                                VoiceConversationEvent.AiReplyChunk(
                                    messageId = messageId,
                                    text = accumulated.toString(),
                                    isStreaming = true
                                )
                            )
                        }
                    }
                }

                val finalReply = accumulated.toString().trim()
                isAiGenerating = false
                if (finalReply.isNotEmpty()) {
                    VoiceSessionBus.emit(
                        VoiceConversationEvent.AiReplyChunk(
                            messageId = messageId,
                            text = finalReply,
                            isStreaming = false
                        )
                    )
                    speak(finalReply)
                } else {
                    val fallback = "দুঃখিত, আমি উত্তর তৈরি করতে পারিনি।"
                    VoiceSessionBus.emit(VoiceConversationEvent.ErrorOccurred(fallback))
                    speak(fallback)
                }
            } catch (e: TimeoutCancellationException) {
                isAiGenerating = false
                Log.e(TAG, "Always-on AI request timed out", e)
                val timeoutMsg = "AI সার্ভার থেকে উত্তর আসতে সময় বেশি লাগছে।"
                VoiceSessionBus.emit(VoiceConversationEvent.ErrorOccurred(timeoutMsg))
                speak(timeoutMsg)
            } catch (e: CancellationException) {
                isAiGenerating = false
                throw e
            } catch (e: Exception) {
                isAiGenerating = false
                Log.e(TAG, "Always-on AI chat failed", e)
                val errorMsg = e.localizedMessage?.takeIf { it.isNotBlank() }
                    ?: "AI সার্ভারের সাথে সংযোগে সমস্যা হয়েছে।"
                VoiceSessionBus.emit(VoiceConversationEvent.ErrorOccurred(errorMsg))
                speak(errorMsg)
            }
        }
    }

    private fun launchTargetApp(target: QuickAppTarget) {
        val (msg, ok) = when (val outcome = DeviceAppLauncher.launch(this, target)) {
            is AppLaunchOutcome.Launched -> outcome.feedbackBn to true
            is AppLaunchOutcome.NotAvailable -> outcome.feedbackBn to false
        }
        VoiceSessionBus.emit(VoiceConversationEvent.ActionPerformed(msg, ok))
        speak(msg)
    }

    private fun speak(rawText: String) {
        val cleanText = rawText
            .replace(Regex("[*#_`~>]+"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()
        if (cleanText.isBlank()) {
            scheduleRestart(300L)
            return
        }

        if (isTtsReady && !isServiceDestroyed) {
            val engine = speaker ?: return
            val hasBengali = cleanText.any { it in '\u0980'..'\u09FF' }
            if (hasBengali) {
                engine.language = Locale.forLanguageTag("bn-BD")
                femaleBengaliVoice?.let { engine.voice = it }
            } else {
                engine.language = Locale.US
                femaleEnglishVoice?.let { engine.voice = it }
            }
            isTtsSpeaking = true
            VoiceSessionBus.setServiceSpeaking(true)
            handler.post { stopRecognitionQuietly() }
            engine.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, "mayra_${System.currentTimeMillis()}")
        } else {
            scheduleRestart(400L)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        isServiceDestroyed = true
        isTtsSpeaking = false
        isAiGenerating = false
        _isRunning.value = false
        VoiceSessionBus.setServiceSpeaking(false)
        VoiceSessionBus.setServiceListening(false)
        activeAiJob?.cancel()
        serviceScope.cancel()
        handler.removeCallbacksAndMessages(null)
        stopRecognitionQuietly()
        runCatching {
            speaker?.stop()
            speaker?.shutdown()
        }
        speaker = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STOP = "com.example.assistant.ACTION_STOP_VOICE_SERVICE"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, MayraVoiceService::class.java)
            ContextCompat.startForegroundService(context, intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, MayraVoiceService::class.java))
        }
    }
}
