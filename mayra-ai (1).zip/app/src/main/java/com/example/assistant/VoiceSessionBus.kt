package com.example.assistant

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface VoiceConversationEvent {
    data class UserSpoken(val text: String) : VoiceConversationEvent
    data class AiReplyChunk(
        val messageId: String,
        val text: String,
        val isStreaming: Boolean
    ) : VoiceConversationEvent
    data class ActionPerformed(val text: String, val succeeded: Boolean) : VoiceConversationEvent
    data class ErrorOccurred(val message: String) : VoiceConversationEvent
}

object VoiceSessionBus {
    private val _events = MutableSharedFlow<VoiceConversationEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<VoiceConversationEvent> = _events.asSharedFlow()

    private val _preferredLanguageTag = MutableStateFlow("bn-BD")
    val preferredLanguageTag: StateFlow<String> = _preferredLanguageTag.asStateFlow()

    private val _serviceSpeaking = MutableStateFlow(false)
    val serviceSpeaking: StateFlow<Boolean> = _serviceSpeaking.asStateFlow()

    private val _serviceListening = MutableStateFlow(false)
    val serviceListening: StateFlow<Boolean> = _serviceListening.asStateFlow()

    fun setLanguageTag(tag: String) {
        _preferredLanguageTag.value = tag
    }

    fun setServiceSpeaking(speaking: Boolean) {
        _serviceSpeaking.value = speaking
    }

    fun setServiceListening(listening: Boolean) {
        _serviceListening.value = listening
    }

    fun emit(event: VoiceConversationEvent) {
        _events.tryEmit(event)
    }
}
