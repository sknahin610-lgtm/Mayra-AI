package com.example.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed interface SpeechRecognitionState {
    data object Idle : SpeechRecognitionState
    data class Listening(
        val rmsDb: Float = 0f,
        val partialTranscript: String = ""
    ) : SpeechRecognitionState
    data class Error(val message: String) : SpeechRecognitionState
}

class MayraSpeechRecognizerManager(private val context: Context) {

    private var speechRecognizer: SpeechRecognizer? = null

    private val _state = MutableStateFlow<SpeechRecognitionState>(SpeechRecognitionState.Idle)
    val state: StateFlow<SpeechRecognitionState> = _state.asStateFlow()

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(
        languageTag: String,
        onResult: (String) -> Unit,
        onUnavailable: () -> Unit
    ) {
        if (!isAvailable()) {
            val msg = if (languageTag.startsWith("bn")) {
                "তোমার ফোনে Speech Recognition পাওয়া যাচ্ছে না"
            } else {
                "Speech recognition is not available on this device."
            }
            _state.value = SpeechRecognitionState.Error(msg)
            onUnavailable()
            return
        }

        stopListeningInternal()

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        speechRecognizer = recognizer

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, languageTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }

        recognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _state.value = SpeechRecognitionState.Listening()
            }

            override fun onBeginningOfSpeech() {}

            override fun onRmsChanged(rmsdB: Float) {
                val current = _state.value
                if (current is SpeechRecognitionState.Listening) {
                    _state.value = current.copy(rmsDb = rmsdB.coerceIn(0f, 12f))
                }
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                val message = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT ->
                        if (languageTag.startsWith("bn")) "কিছু শোনা যায়নি, আবার মাইক্রোফোন চাপো"
                        else "Didn't catch that. Tap the mic to try again."
                    SpeechRecognizer.ERROR_AUDIO ->
                        if (languageTag.startsWith("bn")) "মাইক্রোফোন অডিওতে সমস্যা হয়েছে"
                        else "Microphone audio error."
                    SpeechRecognizer.ERROR_NETWORK,
                    SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        if (languageTag.startsWith("bn")) "নেটওয়ার্ক সংযোগ পরীক্ষা করো"
                        else "Network error during speech recognition."
                    else ->
                        if (languageTag.startsWith("bn")) "আবার মাইক্রোফোন চাপো"
                        else "Tap the microphone to try again."
                }
                _state.value = SpeechRecognitionState.Error(message)
            }

            override fun onResults(results: Bundle?) {
                val data = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val transcript = data?.firstOrNull()?.trim().orEmpty()
                _state.value = SpeechRecognitionState.Idle
                if (transcript.isNotEmpty()) {
                    onResult(transcript)
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    ?.trim()
                    .orEmpty()
                if (partial.isNotEmpty()) {
                    val current = _state.value
                    if (current is SpeechRecognitionState.Listening) {
                        _state.value = current.copy(partialTranscript = partial)
                    }
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        _state.value = SpeechRecognitionState.Listening()
        recognizer.startListening(intent)
    }

    fun stopListening() {
        stopListeningInternal()
        _state.value = SpeechRecognitionState.Idle
    }

    private fun stopListeningInternal() {
        runCatching {
            speechRecognizer?.cancel()
            speechRecognizer?.destroy()
        }
        speechRecognizer = null
    }

    fun destroy() {
        stopListeningInternal()
    }
}
