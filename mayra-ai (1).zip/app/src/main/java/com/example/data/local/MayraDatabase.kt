package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MemoryFactEntity::class], version = 1, exportSchema = false)
abstract class MayraDatabase : RoomDatabase() {
    abstract fun memoryFactDao(): MemoryFactDao

    companion object {
        @Volatile
        private var instance: MayraDatabase? = null

        fun getInstance(context: Context): MayraDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    MayraDatabase::class.java,
                    "mayra_local_memory.db"
                ).build().also { instance = it }
            }
        }
    }
}
