package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Mayra AI", appName)
  }

  @Test
  fun `detectAppCommand recognizes Bengali and English app shortcuts`() {
    assertEquals(
      com.example.assistant.QuickAppTarget.YOUTUBE,
      com.example.assistant.DeviceAppLauncher.detectAppCommand("ইউটিউব খোলো")
    )
    assertEquals(
      com.example.assistant.QuickAppTarget.WHATSAPP,
      com.example.assistant.DeviceAppLauncher.detectAppCommand("open whatsapp")
    )
    assertEquals(
      com.example.assistant.QuickAppTarget.CAMERA,
      com.example.assistant.DeviceAppLauncher.detectAppCommand("ক্যামেরা")
    )
    assertEquals(
      com.example.assistant.QuickAppTarget.CHROME,
      com.example.assistant.DeviceAppLauncher.detectAppCommand("launch chrome")
    )
    assertEquals(
      null,
      com.example.assistant.DeviceAppLauncher.detectAppCommand("আজকের আবহাওয়া কেমন?")
    )
  }

  @Test
  fun `detectMemoryCommand extracts Bengali and English personal facts`() {
    val bnMatch = com.example.data.local.MemoryRepository.detectMemoryCommand("মনে রাখো আমার মিটিং সকাল ৯টায়")
    assertEquals("আমার মিটিং সকাল ৯টায়", bnMatch?.content)

    val enMatch = com.example.data.local.MemoryRepository.detectMemoryCommand("remember that my favorite tea is green tea")
    assertEquals("my favorite tea is green tea", enMatch?.content)

    assertEquals(null, com.example.data.local.MemoryRepository.detectMemoryCommand("আমার নাম কি?"))
  }

  @Test
  fun `detectActionCommand recognizes Bengali and English accessibility navigation`() {
    assertEquals(
      com.example.assistant.AccessibilityControlAction.HOME,
      com.example.assistant.MayraAccessibilityService.detectActionCommand("হোমে যাও")
    )
    assertEquals(
      com.example.assistant.AccessibilityControlAction.BACK,
      com.example.assistant.MayraAccessibilityService.detectActionCommand("go back")
    )
    assertEquals(
      com.example.assistant.AccessibilityControlAction.SCREENSHOT,
      com.example.assistant.MayraAccessibilityService.detectActionCommand("স্ক্রিনশট নাও")
    )
  }
}
